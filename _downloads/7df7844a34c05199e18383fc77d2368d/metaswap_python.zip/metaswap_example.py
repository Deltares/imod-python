"""
Coupled MetaSWAP - Modflow6 model
=================================

The functionality to generate coupled models has been moved to the ``primod`` package. 
`You can find the example here <https://deltares.github.io/iMOD-Documentation/coupler_metamod_example.html>`_ 
"""
